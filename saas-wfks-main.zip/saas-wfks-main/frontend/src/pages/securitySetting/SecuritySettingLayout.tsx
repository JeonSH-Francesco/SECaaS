import { Outlet } from "react-router-dom";

const SecuritySettingLayout = () => {
    return(
        <><Outlet/></>
    )
}

export default SecuritySettingLayout  ; 