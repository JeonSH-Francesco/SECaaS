export type ExceptionIpType = {
    id: number
    client_ip: string,
    client_mask: string,
    version?: string,
    desc: string,
}