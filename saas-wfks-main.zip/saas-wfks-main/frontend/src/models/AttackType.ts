export type AttackType = {
    name? : string,
    count? : number,
    value? : number,
    interval? : string,
}