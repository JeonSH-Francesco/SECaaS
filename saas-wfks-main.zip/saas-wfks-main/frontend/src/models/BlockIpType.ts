export type BlockIpType = {
    id: number,
    ip: string,
    subnetmask: string,
    desc: string
}