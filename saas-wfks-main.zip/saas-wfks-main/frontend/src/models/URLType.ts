export type URLType = {
    id: number
    url: String
    desc : String
}