export type AppType = {
    id : number
}