export type UserType = {
    id: number
    level: number
    app_id: number
    app_name: number
    security_policy_id: number

}
