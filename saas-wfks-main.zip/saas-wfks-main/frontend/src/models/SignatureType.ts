export type SignatureType = {
    id: string
    warning: String
    ko_desc : String
    poc_examples?: String
    impact?: String
}