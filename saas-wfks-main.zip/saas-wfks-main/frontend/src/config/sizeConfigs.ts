const sizeConfigs = {
    sidebar : {
        width : "280px"
    }
};

export default sizeConfigs; 