const styleConfigs = {
    boxShadow : "0px 10px 60px rgba(225.83, 236.19, 248.63, 1)"
}

export default styleConfigs;