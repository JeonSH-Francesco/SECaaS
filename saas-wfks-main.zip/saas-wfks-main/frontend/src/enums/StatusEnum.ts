export enum activeStatus {
    enable = "enable",
    disable = "disable"
}

export enum securityStatus {
    block = "block",
    detect = "detect",
    excpetion = "exception"
}